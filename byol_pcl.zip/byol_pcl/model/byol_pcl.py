import copy
import torch
import torch.nn as nn
from utils import loss_fn, augmentation_func_1, augmentation_func_2

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class EMA():
    def __init__(self, beta):
        super().__init__()
        self.beta = beta

    def update_average(self, old, new):
        if old is None:
            return new
        return old * self.beta + (1 - self.beta) * new


class MLP(nn.Module):
    def __init__(self, dim, projection_size, hidden_size=4096):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_size),
            nn.BatchNorm1d(hidden_size),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_size, projection_size)
        )

    def forward(self, x):
        return self.net(x)


class BYOL_PCL(nn.Module):
    def __init__(self, net, projection_size=256, projection_hidden_size=4096):
        super().__init__()
        self.net = net
        self.projection_size = projection_size
        self.projection_hidden_size = projection_hidden_size
        self.moving_average_decay = 0.99

        self.projector = MLP(1024, 256, 4096)

        self.online_encoder = nn.Sequential(net, self.projector)
        self.target_ema_updater = EMA(self.moving_average_decay)
        self.online_predictor = MLP(projection_size, self.projection_size, self.projection_hidden_size)
        self.aug_func_1 = augmentation_func_1
        self.aug_func_2 = augmentation_func_2
        self.to(device)

    def forward(self, x):
        patch_1, patch_2 = self.aug_func_1(x), self.aug_func_2(x)
        online_proj_1 = self.online_encoder(patch_1)
        online_proj_2 = self.online_encoder(patch_2)

        online_pred_1 = self.online_predictor(online_proj_1)
        online_pred_2 = self.online_predictor(online_proj_2)

        with torch.no_grad():
            target_encoder = copy.deepcopy(self.online_encoder)
            target_proj_1 = target_encoder(patch_1)
            target_proj_2 = target_encoder(patch_2)
            target_proj_1.detach_()
            target_proj_2.detach_()

        loss_1 = loss_fn(online_pred_1, target_proj_2.detach())
        loss_2 = loss_fn(online_pred_2, target_proj_1.detach())

        loss = loss_1 + loss_2
        return loss.mean()