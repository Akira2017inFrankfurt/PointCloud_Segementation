import sys

sys.path.insert(0, '/home/akira/下载/Pointnet2_PyTorch-master/byol_pcl/model')