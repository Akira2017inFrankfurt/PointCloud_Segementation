import os
import numpy as np
import torch
from torch.utils.data import Dataset

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def fps(original, npoints):
    center_xyz = np.sum(original, 0)
    center_xyz = center_xyz / len(original)
    dist = np.sum((original - center_xyz) ** 2, 1)
    farthest = np.argmax(dist)
    distance = np.ones(len(original)) * 1e10
    target_index = np.zeros(npoints, dtype=np.int32)

    for i in range(npoints):
        target_index[i] = farthest
        target_point_xyz = original[target_index[i], :]

        dist = np.sum((original - target_point_xyz) ** 2, 1)
        mask = dist < distance
        distance[mask] = dist[mask]
        farthest = np.argmax(distance)

    return original[target_index]


class PointCloudDataSet_FPS(Dataset):
    def __init__(self, root, npoints=1024):
        super().__init__()
        self.root = root
        self.npoints = npoints
        self.catfile = os.path.join(self.root, 'modelnet40_shape_names.txt')
        self.cat = [line.rstrip() for line in open(self.catfile)]
        self.classes = dict(zip(self.cat, range(len(self.cat))))
        self.split = 'train'
        self.shape_ids = {'train': [line.rstrip() for line in open(os.path.join(self.root, 'modelnet40_train.txt'))],
                          'test': [line.rstrip() for line in open(os.path.join(self.root, 'modelnet40_test.txt'))]}

        self.shape_names = ['_'.join(x.split('_')[0:-1]) for x in self.shape_ids[self.split]]
        self.datapath = [
            (self.shape_names[i], os.path.join(root, self.shape_names[i], self.shape_ids[self.split][i]) + '.txt')
            for i in range(len(self.shape_ids[self.split]))]

        print(f'{len(self.datapath)} point clouds found.')

    def __len__(self):
        return len(self.datapath)

    def __getitem__(self, index):
        path = self.datapath[index][1]
        point_set = np.loadtxt(path, delimiter=',').astype(np.float32)
        point_set = fps(point_set, self.npoints)
        return point_set
