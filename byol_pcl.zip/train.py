import hydra
import torch
import pytorch_lightning as pl
import multiprocessing
from torch.utils.data import DataLoader
from model.byol_pcl import BYOL_PCL
from model.dataset import PointCloudDataSet_FPS
from model.encoder import PCT_Encoder


class SelfSupervisedLearner(pl.LightningModule):
    def __init__(self, net, **kwargs):
        super().__init__()
        self.learner = BYOL_PCL(net, **kwargs)

    def forward(self, images):
        return self.learner(images)

    def training_step(self, images, _):
        loss = self.forward(images)
        return {'loss': loss}

    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=3e-4)

    def on_before_zero_grad(self, _):
        if self.learner.use_momentum:
            self.learner.update_moving_average()


BATCH_SIZE = 4
NUM_POINTS = 1024
EPOCHS = 10
LR = 3e-4
NUM_GPUS = 1
NUM_WORKERS = multiprocessing.cpu_count()

net = PCT_Encoder().cuda()

DATA_PATH = hydra.utils.to_absolute_path('/home/akira/下载/Pointnet2_PyTorch-master/byol_pcl/data/modelnet40_normal_resampled')
ds = PointCloudDataSet_FPS(root=DATA_PATH)
train_loader = DataLoader(ds, batch_size=BATCH_SIZE, num_workers=NUM_WORKERS, shuffle=True)

model = SelfSupervisedLearner(net)

trainer = pl.Trainer(
        gpus=NUM_GPUS,
        max_epochs=EPOCHS,
        accumulate_grad_batches=1,
        sync_batchnorm=False
    )

if __name__ == '__main__':
    trainer.fit(model, train_loader)
