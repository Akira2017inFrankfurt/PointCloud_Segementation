import torch
import torch.nn as nn
import torch.nn.functional as F


# loss fn 损失函数
def loss_fn(x, y):
    x = F.normalize(x, dim=-1, p=2)
    y = F.normalize(y, dim=-1, p=2)
    return 2 - 2 * (x * y).sum(dim=-1)


# SimAttention Class
class SimAttention(nn.Module):
    def __init__(self,
                 sub1, sub2,
                 slice1, slice2,
                 cube1, cube2,
                 sphere1, sphere2,
                 o_encoder,
                 t_encoder,
                 attention_feature_method):
        super().__init__()
        self.sub1 = sub1
        self.sub2 = sub2
        self.slice1 = slice1
        self.slice2 = slice2
        self.cube1 = cube1
        self.cube2 = cube2
        self.sphere1 = sphere1
        self.sphere2 = sphere2
        self.online_encoder = o_encoder
        self.target_encoder = t_encoder

        # todo: can try later
        # self.mlp = projector_mlp

        self.attention_feature = attention_feature_method

    def forward(self, x):
        # [B, 1, N_f] N_f: output dimension of encoder
        sub_feature_1 = self.online_encoder(self.sub1)
        sub_feature_2 = self.target_encoder(self.sub2)

        # slice feature [B, 1, N_f]
        slice_feature_1 = self.online_encoder(self.slice1)
        slice_feature_2 = self.online_encoder(self.slice2)

        # cube feature  [B, 1, N_f]
        cube_feature_1 = self.online_encoder(self.cube1)
        cube_feature_2 = self.online_encoder(self.cube2)

        # sphere feature [B, 1, N_f]
        sphere_feature_1 = self.online_encoder(self.sphere1)
        sphere_feature_2 = self.online_encoder(self.sphere2)

        # crop feature concat [B, 3, N_f]
        crop_feature_1 = torch.cat((slice_feature_1, cube_feature_1, sphere_feature_1), dim=1)
        crop_feature_2 = torch.cat((slice_feature_2, cube_feature_2, sphere_feature_2), dim=1)
        # [B, 6, N_f]
        crop_feature = torch.cat((crop_feature_1, crop_feature_2), dim=1)

        # attention feature
        attn_feature_1 = self.attention_feature(sub_feature_1, crop_feature)
        attn_feature_2 = self.attention_feature(sub_feature_2, crop_feature)

        return loss_fn(attn_feature_1, attn_feature_2)
