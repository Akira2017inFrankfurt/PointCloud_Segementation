import torch
from model import SimAttention
from network.encoder import PCT_Encoder
from network.Augmentation import PointWOLF
from utils.crops import *
from utils.provider import *
from dataloader import ModelNetDataLoader
from torch.utils.data import DataLoader
import logging
import tqdm

logger = logging.getLogger(__name__)

# load method as SimAttention parameter
aug_method = PointWOLF()

online_encoder = PCT_Encoder().cuda()
target_encoder = get_target_encoder(online_encoder)
attention_feature_method = get_attention_feature

model = SimAttention().cuda()

# load data
logger.info('Loading Data...')
file_path = ''
train_set = ModelNetDataLoader(root=file_path, npoint=1024, split='train', normal_channel=False)
train_DataLoader = DataLoader(train_set, batch_size=4, shuffle=True, num_workers=4)
optimizer = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=50, gamma=0.3)

# Training
logger.info('Start training...')
for epoch in range(0, 2):
    model.train()
    for data in train_DataLoader:
        points = data.numpy()
        points = random_point_dropout(points)
        points[:, :, 0:3] = random_scale_point_cloud(points[:, :, 0:3])
        points[:, :, 0:3] = shift_point_cloud(points[:, :, 0:3])

        aug1 = aug_method(points)
        aug2 = aug_method(points)

        sub1, sub2 = torch.Tensor(b_fps(aug1, 1024)).cuda(), torch.Tensor(b_fps(aug2, 1024)).cuda()
        slice1, slice2 = torch.Tensor(b_get_slice(aug1, 1024)).cuda(), torch.Tensor(b_get_slice(aug2, 1024)).cuda()
        cube1, cube2 = torch.Tensor(b_get_cube(aug1, 0.2, 1024)).cuda(), torch.Tensor(b_get_cube(aug2, 0.2, 1024)).cuda()
        sphere1, sphere2 = torch.Tensor(b_get_sphere(aug1, 0.2, 1024)).cuda(), torch.Tensor(b_get_sphere(aug2, 0.2, 1024)).cuda()

        optimizer.zero_grad()
        # todo: when my output is the loss, how do I train it?
        loss = model(sub1, sub2, slice1, slice2, cube1, cube2, sphere1, sphere2,
                     online_encoder, target_encoder, attention_feature_method)
        loss.backward()
        optimizer.step()
    scheduler.step()